class UserController {
     insertUser = (req , res)=> {
         console.log('hogya controller');
         console.log(req.body);

    }

}

module.export = UserController;